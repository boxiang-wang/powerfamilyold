.onLoad=function(libname,pkgname){
   packageStartupMessage("Loaded logitnetFHT ", as.character(packageDescription("logitnetFHT")[["Version"]]),"\n")
}
